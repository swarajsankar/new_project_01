import 'package:flutter/material.dart';

class Appcolor{
  static const Color Primary = Color(0xff2962FF);
  static const Color Dim = Colors.grey;
  static const Color error = Color(0xffD50000);
  static const Color sucecess = Color(0xff00C853);

}